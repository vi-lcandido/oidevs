async function vrau() {
  const xis = await fetch("http://localhost:9090/products");
  console.log(xis);
}

vrau()